<!DOCTYPE HTML>
<!--
	Spectral by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Edit</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="is-preload">

		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
					<header id="header">
						<h1><a href="index.html">ARSIP</a></h1>
						<nav id="nav">
							<ul>
								<li class="special">
									<a href="#menu" class="menuToggle"><span>Menu</span></a>
									<div id="menu">
										<ul>
											<li><a href="tabel.php">Arsip</a></li>
											<li><a href="barang.php">Persediaan</a></li>
											<li><a href="pengguna.php">Pengguna</a></li>
											<li><a href="logout.php">Logout</a></li>
											
										</ul>
									</div>
								</li>
							</ul>
						</nav>
					</header>
					<body class="landing is-preload">
				<!-- Main -->
					
						<section class="wrapper style5">
						
										<table>
										<div class="table-wrapper">
									<?php
	include 'koneksi.php';
	$id = $_GET['id'];
	$data = mysqli_query($koneksi,"select * from aka where id='$id'");
	while($d = mysqli_fetch_array($data)){
?>

		<form method="post" action="update.php">
			<table>
				<tr>			
					<td>Judul</td>
					<td>
						<input type="hidden" name="id" value="<?php echo $d['id']; ?>">
						<input type="text" name="judul" value="<?php echo $d['judul']; ?>">
					</td>
				</tr>
				
				<tr>
					<td>Deskripsi</td>
					<td><input type="text" name="konten" value="<?php echo $d['konten']; ?>"></td>
				</tr>

				<tr>
					<td>Link</td>
					<td><input type="text" name="link" value="<?php echo $d['link']; ?>"></td>
				</tr>

				<tr>
					<td>Kategori</td>
					<td>
					<select name="kategori">
						<option value="LPJ" <?php if($d['kategori'] == 'LPJ'){ echo 'selected'; } ?>>LPJ</option>
						<option value="SPJ" <?php if($d['kategori'] == 'SPJ'){ echo 'selected'; } ?>>SPJ</option>
						<option value="Proposal" <?php if($d['kategori'] == 'Proposal'){ echo 'selected'; } ?>>Proposal</option>
						<option value="Undangan" <?php if($d['kategori'] == 'Undangan'){ echo 'selected'; } ?>>Undangan</option>
						<option value="Surat Keluar" <?php if($d['kategori'] == 'Surat Keluar'){ echo 'selected'; } ?>>Surat Keluar</option>
					</select>
					</td>
				</tr>
				
				<tr>
					<td><input type="submit" value="Simpan"></td>
					<td><button href="index.php">Kembali</button></td>
				</tr>		
			</table>
		</form>
		<?php 
	}
	?>
								
								</section>


		

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>