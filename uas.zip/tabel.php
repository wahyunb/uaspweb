<!DOCTYPE HTML>
<?php 
	session_start();

	// cek apakah yang mengakses halaman ini sudah login
	if($_SESSION['level']==""){
		header("location:login.php");
	}

?>
	
<html>
	<head>
		<title>Arsip</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="is-preload">

		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
					<header id="header">
						<h1><a href="index.html">ARSIP</a></h1>
						<nav id="nav">
							<ul>
								<li class="special">
									<a href="#menu" class="menuToggle"><span>Menu</span></a>
									<div id="menu">
										<ul>
											<li><a href="tabel.php">Arsip</a></li>
											<li><a href="barang.php">Persediaan</a></li>
											<li><a href="pengguna.php">Pengguna</a></li>
											<li><a href="logout.php">Logout</a></li>
											
										</ul>
									</div>
								</li>
							</ul>
						</nav>
					</header>
					<body class="landing is-preload">
				<!-- Main -->
					
						<section class="wrapper style5">
						
										<table>
										<div class="table-wrapper">
										<a href="testambah.php"class="button small">Tambah Arsip</a>
														<thead>
																<tr>
																	<th>Last Update</th>
																	<th>Judul</th>
																	<th>Deskripsi</th>
																	<th>Kategori</th>
																	
																</tr>
														</thead>
															
														<?php 
															include 'koneksi.php';
															$no = 1;
															$data = mysqli_query($koneksi,"select * from aka");
															while($d = mysqli_fetch_array($data)){
														?>
														
														<tr>
															<td><?php echo $d['waktu']; ?></td>
															<td><?php echo $d['judul']; ?></td>
															<td><?php echo $d['konten']; ?></td>
															<td><?php echo $d['kategori']; ?></td><center>
															<td><a href="<?php echo $d['link']?>"class="button small">Download</a></button></center></th>
															<center>
															<td>
															<a href="teseedit.php?id=<?php echo $d['id']; ?>"class="button small">EDIT</a><br>  </center></td>
															<center><td>
														<a href="hapus.php?id=<?php echo $d["id"]?>" onclick =" return confirm ('Hapus?');"class="button primary small fit">HAPUS</a></center></td> 
															</td>
														<?php } ?>
														
														</table>
								
								</section>


		

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>