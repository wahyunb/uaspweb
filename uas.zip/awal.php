<!DOCTYPE HTML>
<!--
	Spectral by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Spectral by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />


				<!-- Header -->
					<header id="header" class="alt">
						<h1><a href="index.html">Spectral</a></h1>
						<nav id="nav">
							<ul>
								<li class="special">
									<a href="#menu" class="menuToggle"><span>Menu</span></a>
									<div id="menu">
										<ul>
											<li><a href="index.html">Home</a></li>
											<li><a href="generic.html">Generic</a></li>
											<li><a href="elements.html">Elements</a></li>
											<li><a href="#">Sign Up</a></li>
											<li><a href="#">Log In</a></li>
										</ul>
									</div>
					
						</nav>
					</header>

			
													<table><center>
                                                        <h2>Arsip</h2>
                                                        <tr>
															<th>NO</th>
															<th>Judul</th>
															<th>Deskripsi</th>
															<th>Link</th>
															<th>Tanggal</th>
														
														</tr><center>
												
															
															<?php 
															include 'koneksi.php';
															$no = 1;
															$data = mysqli_query($koneksi,"select * from aka");
															while($d = mysqli_fetch_array($data)){
																?>
																<tr>
																<td><?php echo $no++; ?></td>
																	<td><?php echo $d['judul']; ?></td>
																	<td><?php echo $d['konten']; ?></td>
																	<center><td>
                                    <button type="button"><a href="<?php echo $d['link']; ?>" target="_blank" > <font color="white"> Download</a></font></button> 
		</td> 
                                     <center>
																
															
																</tr>
																
																<?php 
															}
                                                            ?>
                                                            </table>
                                                        </div>
													
                                                        </section>

	</body>
</html>