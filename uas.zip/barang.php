<!DOCTYPE HTML>
<?php 
	session_start();

	// cek apakah yang mengakses halaman ini sudah login
	if($_SESSION['level']==""){
		header("location:login.php");
	}
?>
<html>
	<head>
		<title>Persediaan</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="is-preload">

		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
					<header id="header">
						<h1><a href="index.html">PERSEDIAAN</a></h1>
						<nav id="nav">
							<ul>
								<li class="special">
									<a href="#menu" class="menuToggle"><span>Menu</span></a>
									<div id="menu">
										<ul>
                                        <li><a href="tabel.php">Arsip</a></li>
											<li><a href="barang.php">Persediaan</a></li>
											<li><a href="pengguna.php">Pengguna</a></li>
											<li><a href="logout.php">Logout</a></li>
											
										</ul>
									</div>
								</li>
							</ul>
						</nav>
					</header>
					<body class="landing is-preload">
				<!-- Main -->
					
						<section class="wrapper style5">
                        <a href="cetakbarang.php" target="_BLANK" class="button small">Cetak</a> <br> <a href="tambah.php"class="button small">Tambah</a>
										<table>
										<div class="table-wrapper">
									
														<thead>
                                                        <tr>
				<th>No</th>
				<th>Tanggal</th>
				<th>Nama Barang</th>
				<th>Jumlah</th>
			</tr>
            <?php 
            include 'koneksi.php';
			$no = 1;
			$data = mysqli_query($koneksi,"select * from barang");
			while($d = mysqli_fetch_array($data)){
			?>
			<tr>
				<td><?php echo $no++; ?></td>
				<td><?php echo $d['tanggal']; ?></td>
				<td><?php echo $d['nama']; ?></td>
                <td><?php echo $d['jumlah']; ?></td>
                <td><a href="edit.php?id=<?php echo $d['id']; ?>"class="button small">EDIT</a><br>  </center></td>
															<center><td>
														<a href="hapusbarang.php?id=<?php echo $d["id"]?>" onclick =" return confirm ('Hapus?');"class="button primary small fit">HAPUS</a></center></td> 
															</td>
			</tr>
			<?php 
			}
			?>
		</table>
								
								</section>


		

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>