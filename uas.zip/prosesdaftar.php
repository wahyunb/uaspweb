<?php
session_start();


   require_once("koneksi.php");
  
   $username = $_POST['username'];
   $pass = md5($_POST['password']);
   $level= $_POST['level'];
   $nama = $_POST['nama'];
   $alamat= $_POST['alamat'];
  
   $sql = "SELECT * FROM user WHERE username = '$username'";
   $query = $koneksi->query($sql);
   
   if(empty($level))  
   {  
    echo "<div align='center'>Pilih Level User!!! <a href='daftar.php'>Back</a></div>";  
   }  
  
   else if($_POST["kode"] != $_SESSION["kode_cap"] OR $_POST["kode"] == "")
   { 
      echo"<div align='center'>kode captcha salah!!! <a href='daftar.php'>Back</a></div>";
   }
   else if($query->num_rows != 0) 
{
   echo "<div align='center'>Username Sudah Terdaftar! <a href='daftar.php'>Back</a></div>";
}




else {
       $data = "INSERT INTO user VALUES ('$nama','$username', '$pass','$level', '$alamat')";
       $simpan = $koneksi->query($data);
          if($simpan) 
       {
         echo "<div align='center'>Pendaftaran Sukses, Silahkan <a href='login.php'>Login</a></div>";
       } 
          else 
       {
         echo "<div align='center'>Proses Gagal!</div>";
       }
  } ?>
  

