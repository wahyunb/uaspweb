<!DOCTYPE HTML>
<!--
	Spectral by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Login</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="landing is-preload">

		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
					<header id="header" class="alt">
						<h1><a href="index.html">Spectral</a></h1>
						
					</header>

				<!-- Banner -->
					<section id="banner">
							<div class="kotak_login">
		<h2 class="tulisan_login"> Login </h2>
 
		<form action="proseslogin.php" method="post">
	
			<input type="text" name="username" class="form_login" placeholder="Username..." required="required"><br><br>
			<input type="password" name="password" class="form_login" placeholder="Password..." required="required"><br><br>
			<input type="submit" class="tombol_login" value="LOGIN"><br> <br>
           <a href="daftar.php" class="button primary">Sign Up</a>
		</form> <br>
				
					</section>

				

			</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

	</body>
</html>