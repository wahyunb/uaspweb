<?php 

include 'koneksi.php';


$id = $_POST['id'];
$nama = $_POST['nama'];
$alamat = $_POST['jumlah'];

date_default_timezone_set('Asia/Jakarta');
$waktu = date('Y-m-d H:i:s');


mysqli_query($koneksi,"update barang set waktu='$waktu', nama='$nama', jumlah='$alamat' where id='$id'");


header("location:barang.php");

?>