<?php 
include 'koneksi.php';

$judul = $_POST['nama'];
$konten = $_POST['jumlah'];

date_default_timezone_set('Asia/Jakarta');
$waktu = date('Y-m-d H:i:s');


mysqli_query($koneksi,"insert into barang values('', '$waktu','$judul','$konten')");


header("location:barang.php");

?>