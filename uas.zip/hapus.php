<?php 
include 'koneksi.php';

$id = $_GET['id'];

mysqli_query($koneksi,"delete from aka where id='$id'");

header("location:tabel.php");

?>