<!DOCTYPE HTML>
<!--
	Spectral by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
-->
<html>
	<head>
		<title>Elements - Spectral by HTML5 UP</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="is-preload">

		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
					<header id="header">
						<h1><a href="index.html">Daftar Akun</a></h1>
						<nav id="nav">
							<ul>
							
							</ul>
						</nav>
					</header>
					<body class="landing is-preload">
				<!-- Main -->
					
						<section class="wrapper style5">
                      
														
										<table>
										<div class="table-wrapper">
									
														<thead>
																<tr>
																	<th>Nama</th>
																	<th>Level</th>
																	<th>Alamat</th>
																	
																	
																</tr>
														</thead>
															
														<?php 
															include 'koneksi.php';
															$no = 1;
															$data = mysqli_query($koneksi,"select * from user");
															while($d = mysqli_fetch_array($data)){
														?>
														
														<tr>
															<td><?php echo $d['nama']; ?></td>
															<td><?php echo $d['level']; ?></td>
															<td><?php echo $d['alamat']; ?></td>
														
															<
														<?php } ?>
														
														</table>
								
								</section>


		

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
            <script>
		window.print();
	</script>
	</body>
</html>