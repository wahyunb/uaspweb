<!DOCTYPE HTML>  
<html>
<head>
<title>Register</title>
<form action="prosesdaftar.php" method="post">
<link rel="stylesheet" href="assets/css/main.css" >
<form action="prosesdaftar.php" method="post">
</head>
<body class="landing is-preload">

		<!-- Page Wrapper -->
			<div id="page-wrapper">

				<!-- Header -->
<?php
// define variables and set to empty values
$username = $password = 
date_default_timezone_set('Asia/Jakarta');
?>
<section id="banner">
  <div class="kotak_login">
<h2 class="tulisan_login"> Register </h2><br>

<form method="post" enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">  
<input type="text" name="nama" class="form_login" placeholder="Nama Lengkap..." required="required"> 
     <br><br>
    <input type="text" name="username" class="form_login" placeholder="Username..." required="required"><br>
			<input type="password" name="password" class="form_login" placeholder="Password..." required="required"><br> <br>
      <input type="text" name="alamat" class="form_login" placeholder="Alamat..." required="required"> 
   <select name="level">
    <option value="">--Pilih Level--</option>
     <option value="Admin">Admin</option>
     <option value="User">User</option> 
       </select><br> <br>
       <img src="capcay.php"/> <br>
  <input type="text" class="cap" placeholder="Masukkan Kode Captcha" required="required" name="kode" ><br><br>
<input type="submit" class="tombol_login" name="submit" value="Daftar"><br> <br>
<a class="tulisan_login" href="login.php"> Punya Akun ? </a>
</section>
</form>




	<!-- Scripts -->
  <script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>






</body>
</html>